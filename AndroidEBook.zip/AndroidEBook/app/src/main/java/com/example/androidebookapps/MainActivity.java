package com.example.androidebookapps;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.androidebookapps.databinding.ActivityMainBinding;
import com.example.fragment.AuthorFragment;
import com.example.fragment.CategoryFragment;
import com.example.fragment.HomeFragment;
import com.example.fragment.LatestFragment;
import com.example.fragment.ProfileFragment;
import com.example.util.BannerAds;
import com.example.util.Constant;
import com.example.util.GDPRChecker;
import com.example.util.Method;
import com.example.util.NotificationTiramisu;
import com.example.util.StatusBar;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MainActivity extends AppCompatActivity {

    ImageView[] imageViews;
    TextView[] textViews;
    LinearLayout[] linearLayouts;
    ActivityMainBinding viewMain;
    FragmentManager fragmentManager;
    boolean doubleBackToExitPressedOnce = false;
    Method method;
    int versionCode;
    FirebaseAnalytics firebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StatusBar.initWhite(MainActivity.this);
        viewMain = ActivityMainBinding.inflate(getLayoutInflater());
        View view = viewMain.getRoot();
        setContentView(view);

        method = new Method(MainActivity.this);
        method.forceRTLIfSupported();
        firebaseAnalytics = FirebaseAnalytics.getInstance(this);
        versionCode = BuildConfig.VERSION_CODE;

        fragmentManager = getSupportFragmentManager();
        linearLayouts = new LinearLayout[]{viewMain.bottomNav.frameHome, viewMain.bottomNav.frameLatest, viewMain.bottomNav.frameCat, viewMain.bottomNav.frameAuthor, viewMain.bottomNav.frameProfile};
        imageViews = new ImageView[]{viewMain.bottomNav.imageHome, viewMain.bottomNav.imageLatest, viewMain.bottomNav.imageCat, viewMain.bottomNav.imageAuthor, viewMain.bottomNav.imageProfile};
        textViews = new TextView[]{viewMain.bottomNav.tvHome, viewMain.bottomNav.tvLatest, viewMain.bottomNav.tvCat, viewMain.bottomNav.tvAuthor, viewMain.bottomNav.tvProfile};

        NotificationTiramisu.takePermission(this);

        if (Constant.isBanner) {
            if (Constant.adNetworkType.equals("Admob")) {
                checkForConsent();
            } else {
                BannerAds.showBannerAds(MainActivity.this, viewMain.layoutAds);
            }
        }

        if (Constant.appUpdateVersion > versionCode && Constant.isAppUpdate) {
            newUpdateDialog();
        }

        selectBottomNav(0);
        HomeFragment homeFragment = new HomeFragment();
        homeFragment.setOnItemClickListener(position -> profileFragment(true, 0));

        loadFrag(homeFragment, "", fragmentManager);
        viewMain.toolbarMain.toolbarToolbar.setVisibility(View.GONE);
        viewMain.bottomNav.frameHome.setOnClickListener(v -> {
            selectBottomNav(0);
            viewMain.toolbarMain.toolbarToolbar.setVisibility(View.GONE);
            HomeFragment homeFragment1 = new HomeFragment();
            homeFragment1.setOnItemClickListener(position -> profileFragment(true, 0));
            loadFrag(homeFragment1, "", fragmentManager);

        });

        viewMain.bottomNav.frameLatest.setOnClickListener(v -> {
            selectBottomNav(1);
            viewMain.toolbarMain.toolbarToolbar.setVisibility(View.GONE);
            LatestFragment latestFragment = new LatestFragment();
            loadFrag(latestFragment, "", fragmentManager);
        });

        viewMain.bottomNav.frameCat.setOnClickListener(v -> {
            selectBottomNav(2);
            viewMain.toolbarMain.toolbarToolbar.setVisibility(View.GONE);
            CategoryFragment categoryFragment = new CategoryFragment();
            loadFrag(categoryFragment, "", fragmentManager);

        });

        viewMain.bottomNav.frameAuthor.setOnClickListener(v -> {
            selectBottomNav(3);
            viewMain.toolbarMain.toolbarToolbar.setVisibility(View.GONE);
            AuthorFragment authorFragment = new AuthorFragment();
            loadFrag(authorFragment, "", fragmentManager);
        });

        viewMain.bottomNav.frameProfile.setOnClickListener(v -> profileFragment(false, 0));

    }

    private void profileFragment(boolean isContinue, int pos) {
        selectBottomNav(4);
        Bundle bundle = new Bundle();
        bundle.putBoolean("isContinue", isContinue);
        bundle.putInt("movePos", pos);
        ProfileFragment profileFragment = new ProfileFragment();
        profileFragment.setArguments(bundle);
        loadFrag(profileFragment, "", fragmentManager);
    }

    private void selectBottomNav(int pos) {
        for (int i = 0; i < linearLayouts.length; i++) {
            if (i == pos) {
                textViews[i].setTextColor(ContextCompat.getColor(MainActivity.this, R.color.bottom_menu_bg_select));
                imageViews[i].setColorFilter(getResources().getColor(R.color.bottom_menu_bg_select), PorterDuff.Mode.SRC_IN);
            } else {
                textViews[i].setTextColor(ContextCompat.getColor(MainActivity.this, R.color.bottom_menu_bg_normal));
                imageViews[i].setColorFilter(getResources().getColor(R.color.bottom_menu_bg_normal), PorterDuff.Mode.SRC_IN);
            }
        }
    }

    public void highLightNavigation(int position) {
        selectBottomNav(position);
        viewMain.toolbarMain.toolbarToolbar.setVisibility(View.GONE);
        LatestFragment latestFragment = new LatestFragment();
        loadFrag(latestFragment, "", fragmentManager);
    }

    public void loadFrag(Fragment f1, String name, FragmentManager fm) {
        for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.frameMain, f1, name);
        ft.commitAllowingStateLoss();
    }

    public void checkForConsent() {
        new GDPRChecker()
                .withContext(MainActivity.this)
                .check();
        BannerAds.showBannerAds(MainActivity.this, viewMain.layoutAds);
    }

    private void newUpdateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(getString(R.string.app_update_title));
        builder.setCancelable(false);
        builder.setMessage(Constant.appUpdateDesc);
        builder.setPositiveButton(getString(R.string.app_update_btn), (dialog, which) -> startActivity(new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(Constant.appUpdateUrl))));
        if (Constant.isAppUpdateCancel) {
            builder.setNegativeButton(getString(R.string.app_cancel_btn), (dialog, which) -> {

            });
        }
        builder.setIcon(R.mipmap.app_icon);
        builder.show();
    }

    @Override
    public void onBackPressed() {
        if (fragmentManager.getBackStackEntryCount() != 0) {
            super.onBackPressed();
        } else {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, getString(R.string.back_key), Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(() -> doubleBackToExitPressedOnce = false, 2000);
        }
    }
}
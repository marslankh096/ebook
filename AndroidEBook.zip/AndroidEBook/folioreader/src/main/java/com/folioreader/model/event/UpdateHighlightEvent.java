package com.folioreader.model.event;

/**
 * Created by gautam on 8/12/17.
 */

public class UpdateHighlightEvent {
}
